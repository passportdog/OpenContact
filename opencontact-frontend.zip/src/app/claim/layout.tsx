export const dynamic = 'force-dynamic'

export default function ClaimLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
